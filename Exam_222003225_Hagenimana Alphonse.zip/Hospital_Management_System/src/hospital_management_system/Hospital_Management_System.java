
package hospital_management_system;

public class Hospital_Management_System {


    public static void main(String[] args) {
        // TODO code application logic here
        login loginframe= new login();
        loginframe.setVisible(true);
        loginframe.pack();
        loginframe.setLocationRelativeTo(null);
    }
    
}
